// -------------------- Utility Function -------------------
function randomColor() {
  return "#" + Math.floor(Math.random() * 16777215).toString(16);
}

//------------------ Mouse Events ---------------------
const mouseBox=document.getElementById("mouseBox");

mouseBox.addEventListener("click", () => {
  mouseBox.style.background=randomColor();
});

mouseBox.addEventListener("dblclick", () => {
  mouseBox.style.width=mouseBox.offsetWidth * 2 + "px";
  mouseBox.style.height=mouseBox.offsetHeight * 2 + "px";
});

mouseBox.addEventListener("mouseenter", () => {
  console.log("Mouse entered");
});

mouseBox.addEventListener("mouseleave", () => {
  console.log("Mouse left");
});

mouseBox.addEventListener("mousemove", (e) => {
  mouseBox.textContent=`X:${e.offsetX}, Y:${e.offsetY}`;
});

// ----------------- Keyboard Events --------------------
// ===== Keyboard Events =====
const circle = document.getElementById("circle");

// Ensure circle starts at defined position
let circleX = parseInt(circle.style.left) || 50;
let circleY = parseInt(circle.style.top) || 300;

document.addEventListener("keydown", (e) => {
  const step = 20;

  if (e.key === "ArrowUp") {
    circleY -= step;
    console.log("ArrowUp pressed → circle moved up");
  } else if (e.key === "ArrowDown") {
    circleY += step;
    console.log("ArrowDown pressed → circle moved down");
  } else if (e.key === "ArrowLeft") {
    circleX -= step;
    console.log("ArrowLeft pressed → circle moved left");
  } else if (e.key === "ArrowRight") {
    circleX += step;
    console.log("ArrowRight pressed → circle moved right");
  } else if (e.code === "Space") {
    console.log("Spacebar pressed!");
    circle.style.background = randomColor();
  }

  // update circle position
  circle.style.left = circleX + "px";
  circle.style.top = circleY + "px";
});

// ----------------- Clipboard Events --------------------
const textArea=document.getElementById("textArea");
const clipboardOutput=document.getElementById("clipboardOutput");

textArea.addEventListener("copy", (e) => {
  const copiedText = window.getSelection().toString();
  clipboardOutput.textContent = "Copied: " + copiedText;
});

textArea.addEventListener("cut", (e) => {
  const cutText = window.getSelection().toString();
  clipboardOutput.textContent = "Cut: " + cutText;
});

textArea.addEventListener("paste", (e) => {
  const pastedText = (e.clipboardData || window.clipboardData).getData("text");
  console.log("Pasted text");
  clipboardOutput.textContent = "Pasted: " + pastedText;
});

// ---------------- Drag & Drop --------------------
const draggableItems = document.querySelectorAll(".draggable");
const dropTarget = document.getElementById("dropTarget");
const dropMessage = document.getElementById("dropMessage");
let shiftPressed = false;

document.addEventListener("keydown", (e) => {
  if (e.key === "Shift") shiftPressed = true;
});
document.addEventListener("keyup", (e) => {
  if (e.key === "Shift") shiftPressed = false;
});

draggableItems.forEach(item => {
  item.addEventListener("dragstart", (e) => {
    e.dataTransfer.setData("text/plain", e.target.id);
  });
});

dropTarget.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropTarget.classList.add("hovered");
});

dropTarget.addEventListener("dragleave", () => {
  dropTarget.classList.remove("hovered");
});

dropTarget.addEventListener("drop", (e) => {
  e.preventDefault();
  dropTarget.classList.remove("hovered");

  const itemId = e.dataTransfer.getData("text/plain");
  const item = document.getElementById(itemId);

  dropMessage.textContent = `Item ${item.textContent} dropped successfully!`;

  if (shiftPressed) {
    item.style.background = randomColor();
  }
});
