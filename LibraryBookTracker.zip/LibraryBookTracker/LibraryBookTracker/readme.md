# 📚 Library Book Tracker

# What I Built :
A simple Library Book Tracker web app that allows users to perform array operations (push, pop, shift, unshift, includes, indexOf) on a list of books using JavaScript.

# Features Used :
- *HTML:* Semantic tags like header, main, section, footer.
- *CSS:* Center alignment, button colors, responsive layout.
- *JavaScript:* Array methods (push, pop, unshift, shift, includes, indexOf), DOM manipulation, event handling.

## How to Run :
- Open "index.html" in your browser.
- Enter book titles separated by commas, then click the buttons to perform operations.

# Assumptions & Limitations:
- Input must be comma-separated.
- Works only for basic array operations.
