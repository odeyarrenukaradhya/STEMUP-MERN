# 🛍️ React Shop – Product List and Cart

## 📘 Overview
A simple React-based e-commerce app where users can view products, add items to the cart, and see the total number of items.  
This project demonstrates React fundamentals like **components**, **props**, **state management**, and **event handling**.

---

## ⚙️ Tech Stack
- **React.js**
- **JavaScript (ES6)**
- **HTML5 & CSS3**

---

## 🧩 Components
- **ShopApp** – Manages products and cart state.  
- **Header** – Displays shop name and cart count.  
- **ProductItem** – Shows product details and includes “Add to Cart” functionality.

---

## 🧠 Key Features
- Add items to cart  
- Toggle product availability (optional)  
- Dynamic rendering using `useState` and props  

---

## 🚀 How to Run
```bash
npm install
npm start


⚠️ Limitations:

- No backend or data persistence
- Cart resets on refresh
- Basic styling only