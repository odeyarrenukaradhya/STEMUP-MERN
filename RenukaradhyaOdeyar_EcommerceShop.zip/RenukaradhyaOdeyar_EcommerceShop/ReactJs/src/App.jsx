import React, { useState } from "react";
import Header from "./components/Header";
import ProductItem from "./components/ProductItem";
import "./App.css";

function App(){
  return(
    <div>
      <Header/>
      <ProductItem/>
      <App/>
    </div>
  )
}

const ShopApp = () => {
  const [cartCount, setCartCount] = useState(0);

  const [products, setProducts] = useState([
    { id: 1, name: "T-Shirt", price: 500, available: true },
    { id: 2, name: "Jeans", price: 1200, available: true },
    { id: 3, name: "Shoes", price: 2000, available: false },
    { id: 4, name: "Cap", price: 300, available: true },
  ]);

  const handleAddToCart = (id) => {
    setCartCount(cartCount + 1);
  };

  // Optional: Toggle availability of product
  const toggleAvailability = (id) => {
    setProducts((prevProducts) =>
      prevProducts.map((product) =>
        product.id === id
          ? { ...product, available: !product.available }
          : product
      )
    );
  };

  return (
    <div className="shop-container">
      <Header cartCount={cartCount} />
      <div className="product-list">
        {products.map((product) => (
          <ProductItem
            key={product.id}
            product={product}
            onAddToCart={handleAddToCart}
            onToggleAvailability={toggleAvailability}
          />
        ))}
      </div>
    </div>
  );
};

export default ShopApp;
