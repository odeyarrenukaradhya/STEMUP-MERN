import React from "react";

const ProductItem = ({ product, onAddToCart, onToggleAvailability }) => {
  const { id, name, price, available } = product;

  return (
    <div
      className="product-card"
      style={{
        backgroundColor: available ? "#fff" : "#f5b7b1",
        opacity: available ? 1 : 0.6,
      }}
    >
      <h2>{name}</h2>
      <p>💰 Price: ₹{price}</p>
      <p>
        Status:{" "}
        <strong style={{ color: available ? "green" : "red" }}>
          {available ? "Available" : "Out of Stock"}
        </strong>
      </p>

      <button
        onClick={() => onAddToCart(id)}
        disabled={!available}
        className="btn"
      >
        {available ? "Add to Cart" : "Unavailable"}
      </button>

      {/* Optional button to toggle product availability */}
      <button onClick={() => onToggleAvailability(id)} className="btn toggle">
        Toggle Availability
      </button>
    </div>
  );
};

export default ProductItem;
