My MiniProject is E-commerce website and its name AstrShop which sells reports and readings.
In this project I have Created products details,Buyers details,order details,Billing,Documents,Terms and Progress,Submit ans reset button etc.
I also added another html page called cart.html which is linked to previous html page astro.html, by clicking on cart option in the astro.html page will take you to the cart section.

----> TAGS I HAVE USED IN THIS PROJECT:

1. <h1> tag - To give the name of this project.
2. <table> tag - To give information or details of the product to the user
3. used emoji to represent order and cart.
4. <marquee> tag - which represent the moving text 
5. <form> tag - To enter the details of product,buyers,order,Billing details.
6. <footer> tag - To represent the copyright and Name.

----> HOW TO OPEN/RUN:

1.Open the zip file which is submitted
2.Then select the folder 'HTML' to open the HTML code, select 'CSS' folder to open CSS code
3.Inside the HTML and CSS folder you can see the text files, then right click on the textfile then select open with and open it on VScode.

----> ASSUMPTIONS AND LIMITATIONS:

• This is a Static Webpage
• The download option works only if we previously added any pdf or file to that.
• The submit button is static and it is resposive interactive.