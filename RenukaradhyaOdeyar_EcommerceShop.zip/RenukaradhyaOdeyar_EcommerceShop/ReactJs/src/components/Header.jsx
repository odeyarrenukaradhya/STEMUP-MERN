import React from "react";

const Header = ({ cartCount }) => {
  return (
    <header className="header">
      <h1>🛍️ React Shop</h1>
      <div className="cart-info">
        🛒 Cart Items: <span>{cartCount}</span>
      </div>
    </header>
  );
};

export default Header;
