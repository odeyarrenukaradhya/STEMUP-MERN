alert("Welcome to Simple Calculator!");
const result = document.getElementById("result");

function appendValue(value) {
  if (result.value.length >= 20) {
    result.value = "Error";
    return;
  }

  if (result.value === "0" || result.value === "Error") {
    result.value = value;
  } else {
    result.value += value;
  }
}

function clearResult() {
  result.value = "0";
}

function deleteLast() {
  if (result.value.length > 1) {
    result.value = result.value.slice(0, -1);
  } else {
    result.value = "0";
  }
}

function calculate() {
  const expression = result.value;


  let allowed = "0123456789.+-*/";
  for (let i = 0; i < expression.length; i++) {
    if (!allowed.includes(expression[i])) {
      result.value = "Error";
      return;
    }
  }


  let operatorCount = 0;
  for (let i = 0; i < expression.length; i++) {
    if ("+-*/".includes(expression[i])) {
      operatorCount++;
      if (operatorCount > 10) {
        result.value = "Error";
        return;
      }
    }
  }

  let numbers = [];
  let operators = [];
  let current = "";

  for (let i = 0; i < expression.length; i++) {
    let char = expression[i];
    if ("+-*/".includes(char)) {
      if (current === "") {
        result.value = "Error";
        return;
      }
      numbers.push(+current); 
      operators.push(char);
      current = "";
    } else {
      current += char;
    }
  }
  numbers.push(+current); 
  let total = numbers[0];
  for (let i = 0; i < operators.length; i++) {
    if (operators[i] === "+") total += numbers[i + 1];
    else if (operators[i] === "-") total -= numbers[i + 1];
    else if (operators[i] === "*") total *= numbers[i + 1];
    else if (operators[i] === "/") {
      if (numbers[i + 1] === 0) {
        result.value = "Error";
        return;
      }
      total /= numbers[i + 1];
    }
  }

  if (total > 999999999) {
    result.value = "Error";
    return;
  }

  result.value = total;
}
