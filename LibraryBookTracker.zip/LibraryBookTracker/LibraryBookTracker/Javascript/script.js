let books = ["Harry Potter", "The Hobbit", "The Alchemist", "Sherlock Holmes"];
const outputDiv = document.getElementById('output');
const bookInput = document.getElementById('bookInput');

function getBooksFromInput() {
    const inputVal = bookInput.value.trim();
    if (inputVal !== "") {
        books = inputVal.split(",").map(item => item.trim());
    }
}

function updateOutput(message) {
    bookInput.value = books.join(", ");
    outputDiv.innerHTML = `<strong>${message}</strong><br>Updated Array: [${books.join(", ")}]`;
}

function addBook() {
    getBooksFromInput();
    const newBook = prompt("Enter book to add:");
    if (newBook) {
        books.push(newBook);
        updateOutput("After Adding (Push):");
    }
}

function removeLastBook() {
    getBooksFromInput();
    books.pop();
    updateOutput("After Removing Last (Pop):");
}

function addAtBeginning() {
    getBooksFromInput();
    const newBook = prompt("Enter book to add at beginning:");
    if (newBook) {
        books.unshift(newBook);
        updateOutput("After Adding at Beginning (Unshift):");
    }
}

function removeFirstBook() {
    getBooksFromInput();
    books.shift();
    updateOutput("After Removing First (Shift):");
}

function checkBook() {
    getBooksFromInput();
    const bookName = prompt("Enter book to check:");
    if (bookName) {
        const isAvailable = books.includes(bookName);
        updateOutput(`Is "${bookName}" available? ${isAvailable}`);
    }
}

function findBook() {
    getBooksFromInput();
    const bookName = prompt("Enter book to find position:");
    if (bookName) {
        const position = books.indexOf(bookName);
        updateOutput(`Position of "${bookName}": ${position}`);
    }
}
