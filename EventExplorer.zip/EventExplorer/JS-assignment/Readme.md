# Event Explorer Game

An interactive web page that demonstrates different *JavaScript events*.  
Users can interact using mouse, keyboard, clipboard, and drag & drop actions, each triggering unique behaviors and console logs.  

-------------------------Implemented Events------------------------
- *Mouse Events*: Click (random color), Double-Click (resize box), Mouse Enter/Leave (console log), Mouse Move (show coordinates).  
- *Keyboard Events*: Arrow keys move a circle, Spacebar changes its color and logs action.  
- *Clipboard Events*: Copy, Cut, and Paste actions are captured and displayed dynamically.  
- *Drag & Drop Events*: Drag items into a target, drop logs success, target highlights, and holding - *Shift* changes item color.  

-------------------------How to Run-----------------------------------
1. Download the zipfile named EventExplorer.
2. Then open the folder named JS-assignment.   
3. Open `index.html` in any modern web browser.  
4. Start interacting with the *box, circle, textarea, and drag items* to see all events in action.  

------------------------ Limitations / Assumptions ---------------------------------
- Works best on desktop browsers (mobile touch events are not included).  
- Keyboard events assume standard arrow keys and spacebar input.  
- Clipboard actions may vary slightly depending on browser security permissions.  